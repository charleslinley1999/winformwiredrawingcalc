﻿using System;
using System.Windows.Forms;
using CalcService;

namespace WireDrawingCalc
{
    public partial class Calc : Form
    {
        private CalcService.CalcService service = new CalcService.CalcService();

        public Calc()
        {
            InitializeComponent();
        }

        private void Calc_Load(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            // Check to see if there is inputs for each one.
            if (!string.IsNullOrEmpty(a1.Text) || !string.IsNullOrEmpty(a2.Text) || !string.IsNullOrEmpty(k.Text) || !string.IsNullOrEmpty(n.Text) || !string.IsNullOrEmpty(r.Text))
            {

                // Test the conversion had issue while i was working...
                //var a1t = double.Parse(a1.Text);
                //var a2t = double.Parse(a2.Text);
                //var kt = int.Parse(k.Text);
                //var nt = double.Parse(n.Text);

                // Had to convert the result to a string...
                p.Text = service.CalculateDrawingForce(double.Parse(a1.Text), double.Parse(a2.Text), int.Parse(k.Text), double.Parse(n.Text), double.Parse(r.Text)).ToString();
            }
            else
            {
                resultlb.Text = "Please enter the values";
            }
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }
    }
}
