﻿namespace WireDrawingCalc
{
    partial class Calc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Calc));
            this.calcresult = new System.Windows.Forms.Button();
            this.resultlb = new System.Windows.Forms.Label();
            this.a1 = new System.Windows.Forms.TextBox();
            this.n = new System.Windows.Forms.TextBox();
            this.r = new System.Windows.Forms.TextBox();
            this.p = new System.Windows.Forms.TextBox();
            this.k = new System.Windows.Forms.TextBox();
            this.a2 = new System.Windows.Forms.TextBox();
            this.a1lb = new System.Windows.Forms.Label();
            this.a2lb = new System.Windows.Forms.Label();
            this.Klb = new System.Windows.Forms.Label();
            this.nlb = new System.Windows.Forms.Label();
            this.rlb = new System.Windows.Forms.Label();
            this.Plb = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // calcresult
            // 
            this.calcresult.Location = new System.Drawing.Point(159, 664);
            this.calcresult.Name = "calcresult";
            this.calcresult.Size = new System.Drawing.Size(280, 236);
            this.calcresult.TabIndex = 0;
            this.calcresult.Text = "Calc";
            this.calcresult.UseVisualStyleBackColor = true;
            this.calcresult.Click += new System.EventHandler(this.Button1_Click);
            // 
            // resultlb
            // 
            this.resultlb.AutoSize = true;
            this.resultlb.Location = new System.Drawing.Point(578, 764);
            this.resultlb.Name = "resultlb";
            this.resultlb.Size = new System.Drawing.Size(95, 37);
            this.resultlb.TabIndex = 1;
            this.resultlb.Text = "result";
            // 
            // a1
            // 
            this.a1.Location = new System.Drawing.Point(159, 199);
            this.a1.Name = "a1";
            this.a1.Size = new System.Drawing.Size(405, 44);
            this.a1.TabIndex = 2;
            // 
            // n
            // 
            this.n.Location = new System.Drawing.Point(159, 507);
            this.n.Name = "n";
            this.n.Size = new System.Drawing.Size(405, 44);
            this.n.TabIndex = 2;
            // 
            // r
            // 
            this.r.Location = new System.Drawing.Point(715, 199);
            this.r.Name = "r";
            this.r.Size = new System.Drawing.Size(405, 44);
            this.r.TabIndex = 2;
            this.r.Text = "0";
            // 
            // p
            // 
            this.p.Location = new System.Drawing.Point(715, 302);
            this.p.Name = "p";
            this.p.Size = new System.Drawing.Size(405, 44);
            this.p.TabIndex = 2;
            // 
            // k
            // 
            this.k.Location = new System.Drawing.Point(159, 411);
            this.k.Name = "k";
            this.k.Size = new System.Drawing.Size(405, 44);
            this.k.TabIndex = 2;
            // 
            // a2
            // 
            this.a2.Location = new System.Drawing.Point(159, 302);
            this.a2.Name = "a2";
            this.a2.Size = new System.Drawing.Size(405, 44);
            this.a2.TabIndex = 2;
            // 
            // a1lb
            // 
            this.a1lb.AutoSize = true;
            this.a1lb.Location = new System.Drawing.Point(59, 202);
            this.a1lb.Name = "a1lb";
            this.a1lb.Size = new System.Drawing.Size(55, 37);
            this.a1lb.TabIndex = 3;
            this.a1lb.Text = "A1";
            this.a1lb.Click += new System.EventHandler(this.Label1_Click);
            // 
            // a2lb
            // 
            this.a2lb.AutoSize = true;
            this.a2lb.Location = new System.Drawing.Point(59, 305);
            this.a2lb.Name = "a2lb";
            this.a2lb.Size = new System.Drawing.Size(57, 37);
            this.a2lb.TabIndex = 3;
            this.a2lb.Text = "A2";
            this.a2lb.Click += new System.EventHandler(this.Label1_Click);
            // 
            // Klb
            // 
            this.Klb.AutoSize = true;
            this.Klb.Location = new System.Drawing.Point(76, 411);
            this.Klb.Name = "Klb";
            this.Klb.Size = new System.Drawing.Size(38, 37);
            this.Klb.TabIndex = 3;
            this.Klb.Text = "K";
            this.Klb.Click += new System.EventHandler(this.Label1_Click);
            // 
            // nlb
            // 
            this.nlb.AutoSize = true;
            this.nlb.Location = new System.Drawing.Point(76, 514);
            this.nlb.Name = "nlb";
            this.nlb.Size = new System.Drawing.Size(41, 37);
            this.nlb.TabIndex = 3;
            this.nlb.Text = "N";
            this.nlb.Click += new System.EventHandler(this.Label1_Click);
            // 
            // rlb
            // 
            this.rlb.AutoSize = true;
            this.rlb.Location = new System.Drawing.Point(644, 202);
            this.rlb.Name = "rlb";
            this.rlb.Size = new System.Drawing.Size(39, 37);
            this.rlb.TabIndex = 3;
            this.rlb.Text = "R";
            this.rlb.Click += new System.EventHandler(this.Label1_Click);
            // 
            // Plb
            // 
            this.Plb.AutoSize = true;
            this.Plb.Location = new System.Drawing.Point(644, 305);
            this.Plb.Name = "Plb";
            this.Plb.Size = new System.Drawing.Size(38, 37);
            this.Plb.TabIndex = 3;
            this.Plb.Text = "P";
            this.Plb.Click += new System.EventHandler(this.Label1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(879, 607);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(2137, 700);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            // 
            // Calc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(3486, 2200);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Plb);
            this.Controls.Add(this.rlb);
            this.Controls.Add(this.nlb);
            this.Controls.Add(this.Klb);
            this.Controls.Add(this.a2lb);
            this.Controls.Add(this.a1lb);
            this.Controls.Add(this.a2);
            this.Controls.Add(this.k);
            this.Controls.Add(this.p);
            this.Controls.Add(this.r);
            this.Controls.Add(this.n);
            this.Controls.Add(this.a1);
            this.Controls.Add(this.resultlb);
            this.Controls.Add(this.calcresult);
            this.Name = "Calc";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Calc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calcresult;
        private System.Windows.Forms.Label resultlb;
        private System.Windows.Forms.TextBox a1;
        private System.Windows.Forms.TextBox n;
        private System.Windows.Forms.TextBox r;
        private System.Windows.Forms.TextBox p;
        private System.Windows.Forms.TextBox k;
        private System.Windows.Forms.TextBox a2;
        private System.Windows.Forms.Label a1lb;
        private System.Windows.Forms.Label a2lb;
        private System.Windows.Forms.Label Klb;
        private System.Windows.Forms.Label nlb;
        private System.Windows.Forms.Label rlb;
        private System.Windows.Forms.Label Plb;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

